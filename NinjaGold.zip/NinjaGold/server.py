from flask import Flask, render_template, request, redirect, session
import random
app = Flask(__name__)
app.secret_key = 'abc123'
@app.route('/')
def mainPage():
    if 'gold' in session:
        print(session['gold'])
    else:
        session['gold'] = 0
    if 'activity' in session:
        print(session['activity'])
    else: 
        session['activity'] = ""
    return render_template('index.html', gold = session['gold'], activity = session['activity'])
@app.route('/processMoney', methods=['POST'])
def process():
    if request.form['building'] == 'farm':
        x = random.randint(10,20)
        session['gold'] += x
        session['activity'] += f"<h3 class='gain'>Obtained {x} gold from your farm.<h3>"
    elif request.form['building'] == 'cave':
        x = random.randint(5,10)
        session['gold'] += x
        session['activity'] += f"<h3 class='gain'>Obtained {x} gold from a cave.<h3>"
    elif request.form['building'] == 'house':
        x = random.randint(2,5)
        x = x * random.randint(1,5)
        session['gold'] += x
        session['activity'] += f"<h3 class='gain'>Obtained {x} gold from your house.<h3>"
    elif request.form['building'] == 'casino':
        x = random.randint(-50,50)
        if x > 0:
            session['gold'] += x
            session['activity'] += f"<h3 class='gain'>Won {x} gold at the Casino.<h3>"
        elif x < 0:
            session['gold'] += x
            session['activity'] += f"<h3 class='lose'>Lost {x} gold at the Casino.<h3>"
        elif x == 0:
            session['activity'] += f"<h3 class='neutral'>you didnt win or lose any gold at the Casino (0)<h3>"
    return redirect('/')
@app.route("/endSession", methods=["POST"])
def reset():
    session['gold'] = 0
    session['activity']= ""
    return redirect("/")
if (__name__ == '__main__'):
    app.run(debug=True)